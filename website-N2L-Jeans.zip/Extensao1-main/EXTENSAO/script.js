src="https://unpkg.com/scrollreveal"

window.revelar = scrollreveal({reset:true})

revelar.reveal('.efeito',
{
   duration: 2000,
   distance: '90px'
})