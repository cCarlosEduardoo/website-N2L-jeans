window.revelar = scrollreveal({reset:true})

revelar.reveal('.efeito',
{
   duration: 2000,
   distance: '90px'
})

revelar.reveal('.descricao',
{
   duration: 2000,
   distance: '90px'
})